READ ME

DOCUMENTS:
The three documents are named HarryPotter, BackToTheFuture, and TheWasteLand.

HOW TO RUN:
Each cell in the jupyter notebook file is answers a section in each part. (One cell for Part2(a), another for Part2(b), etc). Run the entire notebook at once, or cell by cell sequentially. The cell will output the desired variable(s)/charts/answers. The variables containing the answers to each question are clearly commented in every cell. 