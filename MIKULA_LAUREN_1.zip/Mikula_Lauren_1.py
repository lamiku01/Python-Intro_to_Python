
import random


################# down function #################
#retruns number of yards randomly generated based on parameters AND penatly yards (0, 5, or 10)
def down(successprct, yardrange):
    randint = random.randrange(1,100)

    #used to randomly generate penalty
    penalty = [5]*10 + [10]*5 + [0]*85
    rand_penalty = random.choice(penalty)

    if randint < successprct:
        yards = random.randrange(yardrange[0], yardrange[1])
    elif randint >= successprct:
        yards = 0

    return yards, rand_penalty

################# drive function #################
#returns tuple pts_fieldpos which contains points scored and current field position. 1at down is immplemented
def drive(yards_to_TD, successprct, yardrange):
    i = 0
    
    while i <= 4:
        yards_and_penalty = down(successprct, yardrange)
        yards = yards_and_penalty[0]
        penalty = yards_and_penalty[1]
        
        if penalty != 0:
            yards_to_TD = yards_to_TD + penalty
        else:
            yards_to_TD = yards_to_TD - yards    
        
        #f statement used for 1st down option
        if yards - penalty >= 10 and penalty == 0:
            i = 0

        drive_depicted(yards_to_TD, successprct, yardrange, i, penalty)
    
        if yards_to_TD <= 0:
            drive = (random.choice([7, 6]), 80)
            return(drive)
        elif yards_to_TD > 0 and i == 4:
            drive = (0, 100 - yards_to_TD) 
            return(drive)
    
        i = i + 1
    


################# drive depicted function #################
#added parameter i and penalty in order to print current down number and print "P" for a penalty
#if chaning values for these parameters, keep i and penalty as is!!
#prints a visual depiction of a drive
def drive_depicted(yards_to_TD, successprct, yardrange, i, penalty):
     
    drive_visual = ["O","-","-","-","-","|","-","-","-","-","|","-","-","-","-","|","-","-","-","-","|","-","-","-","-","|","-","-","-","-","|","-","-","-","-","|","-","-","-","-","|","-","-","-","-","|","-","-","-","-","X"]
   
    if yards_to_TD > 0:
        even_yard = round((100 - yards_to_TD)//2)*2
        if penalty != 0 and i == 4:
            drive_visual[(even_yard//2)] = "Q"
            print(''.join(drive_visual),end = "   ")
            print("Turnover, with " + str(penalty) + " yrd penalty!! " + str(yards_to_TD) + " yrds to go")
        if penalty == 0 and i == 4:
            drive_visual[(even_yard//2)] = "Q"
            print(''.join(drive_visual),end = "   ")
            print("Turnover," + str(yards_to_TD) + " yrds to go")
        elif penalty != 0 and i != 4 :
            drive_visual[(round((even_yard)//2))] = "P"
            print(''.join(drive_visual),end = "   ")
            print("Down #" + str(i+1) + ", with " + str(penalty) + " yrd penalty!! " + str(yards_to_TD) + " yrds to go")
        else:
            drive_visual[(even_yard//2)] = ">"
            print(''.join(drive_visual),end = "   ")
            print("Down #" + str(i+1) + ", " + str(yards_to_TD) + " yrds to go")
       
    elif yards_to_TD <= 0:
        drive_visual[50] = "T"
        print(''.join(drive_visual),end = "   ")
        print("Touchdown!")
    
    
################# simulate game function #################
#simulates football game with two teams for a chosen amount of drives. returns tuple of two teams' scores
def simulategame(num_drives, prctT1, yrangeT1, prctT2, yrangeT2):
    scoreT1, scoreT2 = 0, 0
    yards_to_TD = 80
    i = 1

    while i <= num_drives:
        print("\n************************************ DRIVE #" + str(i), "************************************")
        if i == 1:
            print("Team 1:")
            drive_output = drive(yards_to_TD, prctT1, yrangeT1)
            scoreT1 = scoreT1 + drive_output[0]
            print("Team 1 Score: ", scoreT1, "\n")
            print("Team 2:")
            drive_output2 = drive(yards_to_TD, prctT2, yrangeT2)
            scoreT2 = scoreT2 + drive_output2[0]
            print("Team 2 Score: ", scoreT2)
        else:
            print("Team 1:")
            drive_output = drive(yards_to_TD, prctT1, yrangeT1)
            scoreT1 = scoreT1 + drive_output[0]
            yards_to_TD = drive_output[1]
            print("Team 1 Score: ", scoreT1, "\n")
            print("Team 2:")
            drive_output2 = drive(yards_to_TD, prctT2, yrangeT2)
            scoreT2 = scoreT2 + drive_output2[0]
            yards_to_TD = drive_output2[1]
            print("Team 2 Score: ", scoreT2)
        print("*********************************************************************************")
        i = i+1

    final_scores = (scoreT1, scoreT2)
    return(final_scores)


################# executes code and prints final scores #################

final_result = simulategame(4, 60, (5,30), 80, (5,30))  #CHANGE THESE VALUES BASED ON (num_drives, prctT1, yrangeT1, prctT2, yrangeT2)

print("\nFinal Score:" + "\nTeam 1: " + str(final_result[0]) + "\nTeam 2: " + str(final_result[1]))
if final_result[0] > final_result[1]:
    print("Team 1 won!!!")
elif final_result[0] < final_result[1]:
    print("Team 2 won!!!")
else:
    print("It's a tie!")
