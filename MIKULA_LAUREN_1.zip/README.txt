README

HOW TO RUN:
Run program as is: the program will run as in once it is downloaded. It runs with line 124 and the parameters (4, 60, (5,30), 80, (5,30)) for the function simulategame.
Run program with changed parameters: change the parameters in line 124 as needed. The parameters are as follows: (num_drives, prctT1, yrangeT1, prctT2, yrangeT2)
Run individual functions with outside script: drive_depicted contains two additional parameters that must be initialized in the 


FUNCTION DESCRIPTIONS:
down(successprct, yardrange) returns a number of yards from the specified rules, defined as the variable 'yards'. It also returns a rendomly genereated penalty amount (either 0, 5, or 10 yards) defined as the variable 'rand_penalty'. 

drive(yards_to_TD, successprct, yardrange) returns a tuple reflected the reams score and either 80 or 100-yards_to_TD. Additionally, "first downs" are implemeted in this function. The if statement on line 37 implements this idea. If the amount of yards gainied (including pentaly) is >= 10, then the down counter (i) is reset to 1.

drive_depicted(yards_to_TD, successprct, yardrange, i, penalty) works as requested, printing out a visualization of a drive. The paramenters i and penalty were added in order to 1) keep track of the down # and 2) if there was a pentaly, display it with the character 'P'. Both of these aspects are not necessary for the funtion to work, but it does improve readability in the final output. WHEN CALLING THIS FUNCTION WITH OUTSIDE SCRIPT: i can be selected as any chosen down # (1,2,3,4) and penalty can be chosen as any penalty amount (0,5,10)

simulategame(num_drives, prctT1, yrangeT1, prctT2, yrangeT2) function works as requested. It returns a two element tuple containing team 1's score and team 2's score.