from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import KFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import ElasticNet
from sklearn.linear_model import Lasso
from sklearn.metrics import confusion_matrix
import pandas as pd

#-------------- Part 1. Machine Learning (Classification) --------------#

#-------- Part 1 (a) --------#
cancer = load_breast_cancer()
X, y = load_breast_cancer(return_X_y = True)

#-------- Part 1 (b) --------#
print("\n--------Part 1(b)--------")
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=11)

def classificationEstimators(kfold):
    knn = KNeighborsClassifier()
    knn.fit(X=X_train, y=y_train)
    knn_predicted_labels = knn.predict(X=X_test)
    knn_expected_labels = y_test 
    knn_scores = cross_val_score(knn, X, y, cv=kfold)
    print("\tkNeighbors Classifier: ", end='')
    print(f'{knn_scores.mean():.2%}')

    gnb = GaussianNB()
    gnb.fit(X=X_train, y=y_train)
    gnb_predicted_labels = gnb.predict(X=X_test)
    gnb_expected_labels = y_test 
    gnb_scores = cross_val_score(gnb, X, y, cv=kfold)
    print("\tGaussian Naive Bayes Classifier: ", end='')
    print(f'{gnb_scores.mean():.2%}')

    svc = SVC()
    svc.fit(X=X_train, y=y_train)
    svc_predicted_labels = svc.predict(X=X_test)
    svc_expected_labels = y_test 
    svc_scores = cross_val_score(svc, X, y, cv=kfold)
    print("\tSupport Vector Classifier: ", end='')
    print(f'{svc_scores.mean():.2%}')

    return(knn_predicted_labels,knn_expected_labels, gnb_predicted_labels, gnb_expected_labels, svc_predicted_labels, svc_expected_labels)


kfold = KFold(n_splits=2, random_state=11, shuffle=True)

print("\n2-Fold Cross-Validation:")
two_fold_predicted_list = classificationEstimators(kfold)

#-------- Part 1 (c) --------#
print("\n--------Part 1(c)--------")

kfold = KFold(n_splits=20, random_state=11, shuffle=True)

print("\n20-Fold Cross-Validation:")
twenty_fold_predicted_list = classificationEstimators(kfold)

#-------- Part 1 (d) --------#
#most accurate model is 2-fold Gaussian 
print("\n--------Part 1(d)--------")
most_accurate_expeted =two_fold_predicted_list[2]
most_accurate_predicted =two_fold_predicted_list[3]
confusion = confusion_matrix(y_true=most_accurate_expeted, y_pred=most_accurate_predicted)
print("\nConfusion matrix: \n")
print(confusion)





#-------------- Part 2. Option II (Machine Learning (Regression)) --------------#

#-------- Part 2 (a) --------#
weather = pd.read_csv('C:/Users/laure/Downloads/Senior year (Fall 2021 - Spring 2022)/Spring 2022/CSE 590-59 (Python)/homework/HW4/weatherHistory.csv')
weather = weather.rename(columns={'Apparent Temperature (C)':'ApparentTemperature'})

#-------- Part 2 (b) --------#
print("\n--------Part 2(b)--------")
X = weather.ApparentTemperature.values.reshape(-1, 1)
y = weather.Humidity.values

X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=11)

def regression(kfold, scoring):

    linear_regression = LinearRegression()
    linear_regression.fit(X=X_train, y=y_train)
    predicted = linear_regression.predict(X_test)
    expected = y_test
    scores = cross_val_score(estimator=linear_regression, X=X, y=y, cv=kfold,scoring=scoring)
    print(f'\tLinear regression: mean of scores = {scores.mean():.3f}')

    lasso = Lasso()
    lasso.fit(X=X_train, y=y_train)
    predicted = lasso.predict(X_test)
    expected = y_test
    scores = cross_val_score(estimator=lasso, X=X, y=y, cv=kfold,scoring=scoring)
    print(f'\tLasso: mean of scores = {scores.mean():.3f}')

    elasticnet = ElasticNet()
    elasticnet.fit(X=X_train, y=y_train)
    predicted = elasticnet.predict(X_test)
    expected = y_test
    scores = cross_val_score(estimator=elasticnet, X=X, y=y, cv=kfold,scoring=scoring)
    print(f'\tElasticNet: mean of scores = {scores.mean():.3f}')

kfold = KFold(n_splits=10, random_state=11, shuffle=True)
print("\nR-Squared Score: \n")
regression(kfold,'r2')

#-------- Part 2 (c) --------#
print("\n--------Part 2(c)--------")
kfold = KFold(n_splits=10, random_state=11, shuffle=True)
print("\nMean Square Error Score: \n")
regression(kfold,'neg_mean_squared_error')
