README

HOW TO RUN:
Run the program as given. All necessary outputs will be printed to the terminal. Each part is clearly labeled in the output. 

PART 1(a):
The chosen sklearn dataset is breast_cancer()

PART 1(b):
The three chosen classification models are KNeighborsClassifier, GaussianNB, and SVC.

PART 1(d):
The most accurate model chosen for this part is the 2-fold GaussianNB model


PART 2:
Option II is chosen for this project. The csv file used is included in the zip file (weatherHistory.csv)

PART 2(b):
The three chosen regression models are LinearRegression, ElasticNet, and Lasso. 
