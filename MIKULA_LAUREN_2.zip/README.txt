README

HOW TO RUN:
Download TheWonderfulWizardOfOz.txt for the text file.
Change the file path in line 5 to reflect the location of the text file.
Run all cells at once or one at a time. 

HOW TO GENERATE LISTS/DATA-FRAME:
Each cell in my .ipynb file corresponds to each part of the assignment (excluding Part A). In order to generate the lists/data-frames, run the cells sequentially. The last line of each cell shows the variable name of the list or data-frame. The output of each cell will give you the list or data-frame. 

The requested list/data-frame varible names are as follows:
Part B: word_list
Part C: df
Part D: df_stopwords_sorted
Part E: df_list